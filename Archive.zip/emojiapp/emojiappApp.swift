//
//  emojiappApp.swift
//  emojiapp
//
//  Created by matt on 10/25/25.
//

import SwiftUI

@main
struct emojiappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
